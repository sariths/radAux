libtiff 4.0.7

Compiled with VS 2015 64 bits with zlib support.
